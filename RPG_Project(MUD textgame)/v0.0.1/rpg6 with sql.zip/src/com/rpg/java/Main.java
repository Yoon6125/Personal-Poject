package com.rpg.java;

public class Main {

	public static void main(String[] args) {
		GameMenuProcess gmp = new GameMenuProcess();
		gmp.run();

	}

}
