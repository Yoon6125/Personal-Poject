package com.rpg.character.java;

import java.sql.SQLException;

import com.rpg.sqldata.java.DatabaseConnect;

public class CharacterExist {
	CreateCharacter cch = new CreateCharacter();

	public boolean exist() {
		DatabaseConnect.dbInit();
		boolean hasCharacter = false;
		try {
			DatabaseConnect.result = DatabaseConnect.st.executeQuery("select * from user_ch;");

			while (DatabaseConnect.result.next()) {
				hasCharacter = true;
			}
			if (!hasCharacter) {
				System.out.println("캐릭터 없음 생성 필요 - 자동으로 캐릭터 생성창으로 이동합니다");
				cch.run();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hasCharacter;

	}
}
