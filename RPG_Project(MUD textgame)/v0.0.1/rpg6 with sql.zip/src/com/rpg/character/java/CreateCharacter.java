package com.rpg.character.java;

import java.util.Scanner;

import com.rpg.sqldata.java.DatabaseConnect;

public class CreateCharacter {
	Scanner sc = new Scanner(System.in);

	public void run() {
		DatabaseConnect.dbInit();
		int ap = 0;
		int dp = 0;
		int sp = 0;
		int hp = 0;
		int exp = 0;
		int level = 0;
		String j;
		String name;
		System.out.println("--------------------------------------------------------");
		System.out.println("-------------------------캐릭터 생성-----------------------");
		System.out.println("--------------------------------------------------------");
		while (true) {
			System.out.println("캐릭터 명 작성 (8자리 띄어쓰기 포함) : ");
			name = sc.nextLine();
			if (name.length() > 8) {
				System.out.println("이름 값 범위를 초과하였습니다.");
			} else {
				System.out.println("이름 작성 완료");
				break;
			}
		}
		loop_xx: while (true) {
			System.out.println("직업을 선택해 주세요 (숫자 입력)");
			System.out.println("1.중보병  / 2. 기사 / 3. 사수 ");
			String job = sc.nextLine();
			switch (job) {
			case "1":
				System.out.println("중보병을 선택하셨습니다.");
				j = "중보병";
				ap = 100;
				dp = 300;
				sp = 20;
				hp = 1000;
				exp = 0;
				level = 1;
				break loop_xx;
			case "2":
				System.out.println("기사를 선택하셨습니다.");
				j = "기사";
				ap = 150;
				dp = 100;
				sp = 50;
				hp = 500;
				exp = 0;
				level = 1;
				break loop_xx;
			case "3":
				System.out.println("사수를 선택하셨습니다.");
				j = "사수";
				ap = 280;
				dp = 80;
				sp = 100;
				hp = 200;
				exp = 0;
				level = 1;
				break loop_xx;
			default:
				System.out.println("목록에 있는 직업을 선택해주세요");
				continue;
			}
		}
		String sql = String.format(
				"insert into user_ch (c_name,c_job,c_attackpoint,c_defencepoint,c_hp,c_speed, exp,c_level) values('%s','%s',%d,%d,%d,%d,%d,%d);",
				name, j, ap, dp, hp, sp, exp, level);

		DatabaseConnect.dbExecuteUpdate(sql);

	}
}
