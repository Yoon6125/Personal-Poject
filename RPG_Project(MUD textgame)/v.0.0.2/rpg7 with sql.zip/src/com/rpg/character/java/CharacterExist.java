package com.rpg.character.java;

import java.sql.SQLException;
import java.util.ArrayList;

import com.rpg.member.java.MemberLogin;
import com.rpg.sqldata.java.DatabaseConnect;

public class CharacterExist {
	CreateCharacter cch = new CreateCharacter();
	MemberLogin ml = new MemberLogin();
	static public ArrayList<String> cha_data = new ArrayList<String>();

	public boolean exist() {
		DatabaseConnect.dbInit();

		boolean hasCharacter = false;
		String sql = String.format("select * from rpg_memberanduser where id_member ='%s';", ml.userid);
		try {
			DatabaseConnect.result = DatabaseConnect.st.executeQuery(sql);
			cha_data.clear();
			while (DatabaseConnect.result.next()) {
				cha_data.add(DatabaseConnect.result.getString("c_name"));
				hasCharacter = true;
			}
			if (!hasCharacter) {
				System.out.println("캐릭터 없음 생성 필요 - 자동으로 캐릭터 생성창으로 이동합니다");
				cch.run();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hasCharacter;

	}
}
