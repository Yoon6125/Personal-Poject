package com.rpg.interact.java;

public class RolldiceInteraction {
	public int run() {
		int a = (int) (Math.random() * 6 + 1);
		String n = String.format("주사위를 돌려 %d 가 나왔습니다.", a);
		System.out.println(n);
		return a;
	}
}
