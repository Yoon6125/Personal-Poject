package com.rpg.logo.java;

public class TitleLogo {
	public void run() {
		System.out.println("-----------------------------------------------------------------");
		System.out.println("--------------------------RPG 머드게임 v.0.0.2----------------------");
		System.out.println("-----------------------------------------------------------------");

	}
}
