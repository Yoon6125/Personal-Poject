package com.rpg.java;

public class Main {

	public static void main(String[] args) {
//		CreateCharacter cch = new CreateCharacter();
		GameMenuProcess gmp = new GameMenuProcess();
		gmp.run();

	}

}
