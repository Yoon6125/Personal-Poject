package com.rpg.java;

public class GameStory {
	public void run() {
		System.out.println("");
	}
}
