package com.rpg.interact.java;

import java.util.Scanner;

public class RolldiceInteraction {
	Scanner sc = new Scanner(System.in);

	public int run() {
		int a = 0;
		loop_lo: while (true) {
			System.out.println("1. 주사위를 굴리기      2.주사위를 굴리지 않기");
			String roll = sc.nextLine();
			switch (roll) {
			case "1":
				a = (int) (Math.random() * 6 + 1);
				String n = String.format("주사위를 돌려 %d 가 나왔습니다.", a);
				System.out.println(n);
				break loop_lo;
			case "2":
				System.out.println("취소");
				break loop_lo;
			default:
				continue;
			}

		}
		return a;
	}
}
