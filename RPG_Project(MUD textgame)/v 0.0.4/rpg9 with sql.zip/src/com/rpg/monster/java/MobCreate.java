package com.rpg.monster.java;

import java.sql.SQLException;

import com.rpg.sqldata.java.DatabaseConnect;

public class MobCreate {
//	static public String name = "";
//	static public int moAp = 0;
//	static public int moDp = 0;
//	static public int moHp = 0;
//	static public int moExp = 0;
//	static public int moSpeed = 0;

	static public Monster mo;

	public void run(String a) {
		DatabaseConnect.dbInit();
//		ArrayList<String> a1 = new ArrayList<>();
//		ArrayList<Integer> a2 = new ArrayList<>();
//		ArrayList<Integer> a3 = new ArrayList<>();
//		ArrayList<Integer> a4 = new ArrayList<>();
//		ArrayList<Integer> a5 = new ArrayList<>();
//		ArrayList<Integer> a6 = new ArrayList<>();
//		int mobnum = (int) (Math.random() * 2 + 1);
//		a1.clear();
//		a2.clear();
//		a3.clear();
//		a4.clear();
//		a5.clear();
//		a6.clear();

//		int idtt2 = 0;
		String b = String.format("select * from mob_mo where region='%s'", a);
		try {
			DatabaseConnect.result = DatabaseConnect.st.executeQuery(b);
			while (DatabaseConnect.result.next()) {
				mo = new Monster(DatabaseConnect.result.getString("mo_name"),
						DatabaseConnect.result.getInt("mo_attackpoint"),
						DatabaseConnect.result.getInt("mo_defencepoint"), DatabaseConnect.result.getInt("mo_hp"),
						DatabaseConnect.result.getInt("mo_speed"), DatabaseConnect.result.getInt("exp"),
						DatabaseConnect.result.getInt("mo_level"));

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		System.out.println("Selected Monster: " + mo.name);
		System.out.println("Attack Power: " + mo.attackpoint);
		System.out.println("Defence Power: " + mo.defencepoint);
		System.out.println("HP: " + mo.hp);
		System.out.println("EXP: " + mo.exp);
		System.out.println("Speed: " + mo.speed);

	}
}
