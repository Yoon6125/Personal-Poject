package com.rpg.monster.java;

public class Monster {
	public String name;
	public int attackpoint;
	public int defencepoint;
	public int hp;
	public int speed;
	public int exp;
	public int level;

	public Monster(String name, int attackpoint, int defencepoint, int hp, int speed, int exp, int level) {
		this.name = name;
		this.attackpoint = attackpoint;
		this.defencepoint = defencepoint;
		this.hp = hp;
		this.speed = speed;
		this.exp = exp;
		this.level = level;
	}

}
