package com.rpg.character.java;

import java.sql.SQLException;
import java.util.Scanner;

import com.rpg.member.java.MemberLogin;
import com.rpg.sqldata.java.DatabaseConnect;

public class SelectPlayer {
	Scanner sc = new Scanner(System.in);
	MemberLogin ml = new MemberLogin();
	String a = "";
//	static public String charName = "";
//	static public String charJob = "";
//	static public int charLevel = 0;
//	static public int charAp = 0;
//	static public int charDp = 0;
//	static public int charHp = 0;
//	static public int charSpeed = 0;
//	static public int charExp = 0;

	static public Character ch;

	public boolean run() {
		System.out.println("********캐릭터 목록***********");
		for (int i = 0; i < CharacterExist.cha_data.size(); i++) {
			DatabaseConnect.dbInit();
			a = String.format("select * from user_ch where c_name='%s';", CharacterExist.cha_data.get(i));
			DatabaseConnect.dbExecuteQuery(a);
		}
//
//		ArrayList<String> name = new ArrayList<>();
//		ArrayList<String> job = new ArrayList<>();
//		ArrayList<Integer> level = new ArrayList<>();
//		ArrayList<Integer> ap = new ArrayList<>();
//		ArrayList<Integer> dp = new ArrayList<>();
//		ArrayList<Integer> hp = new ArrayList<>();
//		ArrayList<Integer> speed = new ArrayList<>();
//		ArrayList<Integer> exp = new ArrayList<>();

//		name.clear();
//		job.clear();
//		level.clear();
//		ap.clear();
//		dp.clear();
//		hp.clear();
//		speed.clear();
//		exp.clear();
		boolean chooseCharacter = false;

		System.out.println("플레이할 캐릭터 이름을 타이핑 하세요 :");
		String choosechar = sc.nextLine();
		DatabaseConnect.dbInit();
		if (choosechar != null && !choosechar.isEmpty()) {

			String b = String.format("select * from user_ch where c_name ='%s';", choosechar);

			try {
				DatabaseConnect.result = DatabaseConnect.st.executeQuery(b);
				if (DatabaseConnect.result.next()) {
					// 캐릭터가 존재하면 선택 완료
					ch = new Character(DatabaseConnect.result.getString("c_name"),
							DatabaseConnect.result.getString("c_job"), DatabaseConnect.result.getInt("c_defencepoint"),
							DatabaseConnect.result.getInt("c_attackpoint"), DatabaseConnect.result.getInt("c_hp"),
							DatabaseConnect.result.getInt("c_speed"), DatabaseConnect.result.getInt("exp"),
							DatabaseConnect.result.getInt("c_level"));

					chooseCharacter = true; // 캐릭터 선택 성공
				} else {
					System.out.println("선택한 캐릭터가 존재하지 않습니다.");
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			charName
//			charJob
//			charLevel
//			charAp
//			charDp
//			charHp
//			charSpeed
////			charExp
//			charName = name.get(0);
//			charJob = job.get(0);
//			charLevel = level.get(0);
//			charAp = ap.get(0);
//			charDp = dp.get(0);
//			charHp = hp.get(0);
//			charSpeed = speed.get(0);
//			charExp = exp.get(0);
			System.out.println("캐릭터 선택 완료: " + ch.name + " (직업: " + ch.job + ", 레벨: " + ch.level + ")");

		} else {
			System.out.println("올바른 캐릭터명을 입력하세요");
		}

		return chooseCharacter;
	}
}
