package com.rpg.character.java;

public class Character {
	public String name = "";
	public String job = "";
	public int attackpoint = 0;
	public int defencepoint = 0;
	public int hp = 0;
	public int speed = 0;
	public int exp = 0;
	public int level = 0;

	public Character(String name, String job, int attackpoint, int defencepoint, int hp, int speed, int exp,
			int level) {
		this.name = name;
		this.job = job;
		this.attackpoint = attackpoint;
		this.defencepoint = defencepoint;
		this.hp = hp;
		this.speed = speed;
		this.exp = exp;
		this.level = level;
	}

}
