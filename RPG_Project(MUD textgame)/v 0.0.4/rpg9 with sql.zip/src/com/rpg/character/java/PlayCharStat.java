package com.rpg.character.java;

import com.rpg.java.Gamebattle;

public class PlayCharStat {

	public void run() {
//		DatabaseConnect.dbInit();
		String name = SelectPlayer.ch.name;
		String job = SelectPlayer.ch.job;
		int hp = SelectPlayer.ch.hp;
		int level = SelectPlayer.ch.level;
		int ap = SelectPlayer.ch.attackpoint;
		int dp = SelectPlayer.ch.defencepoint;
		int exp = SelectPlayer.ch.exp;

		if (Gamebattle.debuff == true) {
			ap = ap - 20;
		}

//		String a = String.format("select * from user_ch where c_name ='%s';", SelectPlayer.ch.name);

		System.out.println("이름:" + name + " 직업: " + job + " 현재체력: " + hp + " 현제 레벨: " + level);
		System.out.println("공:" + ap + " 방: " + dp + " 경험치: " + exp);
	}
}
