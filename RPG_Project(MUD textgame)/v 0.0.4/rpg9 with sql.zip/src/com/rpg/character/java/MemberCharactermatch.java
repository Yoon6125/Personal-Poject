package com.rpg.character.java;

import com.rpg.member.java.MemberLogin;
import com.rpg.sqldata.java.DatabaseConnect;

public class MemberCharactermatch {
//	CreateCharacter cch = new CreateCharacter();

	public void run(String name) {
		DatabaseConnect.dbInit();
		MemberLogin ml = new MemberLogin();

		String dataname = name;
		String membername = ml.userid;
		String data = String.format("insert into rpg_memberanduser(id_member ,c_name) values('%s' , '%s') ", membername,
				dataname);
		DatabaseConnect.dbExecuteUpdate(data);
		System.out.println("처리 완료");

	}
}
