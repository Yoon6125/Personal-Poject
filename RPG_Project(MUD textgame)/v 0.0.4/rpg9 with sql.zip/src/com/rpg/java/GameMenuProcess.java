package com.rpg.java;

import java.util.Scanner;

import com.rpg.character.java.CharacterExist;
import com.rpg.character.java.Checkmychar;
import com.rpg.character.java.CreateCharacter;
import com.rpg.character.java.DeleteCharacter;
import com.rpg.character.java.SelectPlayer;
import com.rpg.logo.java.TitleLogo;
import com.rpg.member.java.MemberLoginMain;
import com.rpg.sqldata.java.DatabaseConnect;

public class GameMenuProcess {
	TitleLogo tl = new TitleLogo();
	MemberLoginMain mlm = new MemberLoginMain();
	CreateCharacter cch = new CreateCharacter();
	CharacterExist che;
	DeleteCharacter dch = new DeleteCharacter();
	Checkmychar ckch = new Checkmychar();
	SelectPlayer slp;
	GameStory gst;
	Scanner sc = new Scanner(System.in);

	// 로그인 기능 추가(24.09.06)
	public void run() {
		DatabaseConnect.dbInit();
		if (mlm.run() == true) {
			int exitprop = 0;
			System.exit(exitprop);
		}

		loop_xx: while (true) {
			tl.run();
			System.out.println("1.게임 하기 / 2. 캐릭터 만들기 / 3.캐릭터 확인 / 4.캐릭터 삭제 / x.종료");
			String choose = sc.nextLine();
			switch (choose) {
			case "1":
				che = new CharacterExist();
				if (che.exist() == true) {
					// todo
					// 플레이 캐릭터 선택(완료)-> 게임 진행
					// 몬스터 생성 및 전투 알고리즘
					// 레벨업 및 경험치 획득 기능
					// 세이브 기능(쿼리 넘겨주고 업데이트만 해주면 됄듯?)
					slp = new SelectPlayer();
					if (slp.run() == true) {
						gst = new GameStory();
						gst.run();
					}
				}
				break;
			case "2":
				cch.run();
				break;
			case "3":
				ckch.run();
				break;
			case "4":
				dch.run();
				break;
			case "x":
				break loop_xx;
			default:
				System.out.println("재대로 입력해주세요");
				continue;
			}
		}
	}
}