package com.rpg.java;

import java.sql.SQLException;
import java.util.Scanner;

import com.rpg.character.java.PlayCharStat;
import com.rpg.character.java.SelectPlayer;
import com.rpg.interact.java.RolldiceInteraction;
import com.rpg.monster.java.MobCreate;
import com.rpg.sqldata.java.DatabaseConnect;

public class Gamebattle {
	RolldiceInteraction rdi = new RolldiceInteraction();
//	MobCreate mc = new MobCreate();
//	SelectPlayer spl = new SelectPlayer();
	CompareSpeed cs = new CompareSpeed();
	Scanner sc = new Scanner(System.in);
//	int damCalcuser = (int) (Math.random() * (spl.charAp - mc.moDp)) + 1;
//	int damCalcmob = (int) (Math.random() * (mc.moAp - spl.charDp)) + 1;

	PlayCharStat pcs;

	public static boolean debuff = false;
	boolean dor = true;

	private int calculateDamage(int attpw, int defpow) {
		return Math.max(1, (int) (Math.random() * (attpw - defpow)) + 1);
	}

	int userhp = SelectPlayer.ch.hp;
	int mobhp = MobCreate.mo.hp;
	int playerlevel = SelectPlayer.ch.level;
	int userExp = SelectPlayer.ch.exp;

	public void run() {

		// 디버프 적용 여부 확인
		int userAttackPower = debuff ? SelectPlayer.ch.attackpoint - 20 : SelectPlayer.ch.attackpoint;
		int userhpleft = userhp;
		System.out.println(userhpleft);
		int mobhpleft = mobhp;
		System.out.println(mobhpleft);
//		if (debuff == true) {
//			damCalcuser = damCalcuser - 20;
//		}
		System.out.println(MobCreate.mo.name + "이 나타났다");

		if (cs.run() == false) {
			System.out.println("적의 공격: 당신은 피해를 입었다");
			int damCalcmob = calculateDamage(MobCreate.mo.attackpoint, SelectPlayer.ch.defencepoint);
			userhpleft -= damCalcmob;
		}
		System.out.println("전투 개시");
		loop_x: while (true) {
			System.out.println("1.공격        2.방어       3.도망      4.상태보기       5.아이템 사용");
			String choose = sc.nextLine();
			switch (choose) {
			case "1":
				// 공격 처리
				int damCalcuser = calculateDamage(userAttackPower, MobCreate.mo.defencepoint);
				int damCalcmob = calculateDamage(MobCreate.mo.attackpoint, SelectPlayer.ch.defencepoint);
				System.out.println(damCalcuser);
				System.out.println("당신은 적에게 일격을 날렸다");
				mobhpleft = mobhpleft - damCalcuser;
				// 적 생존시 반격
				if (mobhpleft > 0) {
					System.out.println("적 또한 당신에게 일격을 날렸다");
					userhpleft = userhpleft - damCalcmob;
					System.out.println("당신은" + damCalcmob + "의 피해를 입었다");
				}
				// 전투 종료
				if (mobhpleft <= 0) {
					DatabaseConnect.dbInit();// db 연결
					String x = "";
					String x1 = "";
					// 트랜잭션 시작

					try {
						DatabaseConnect.con.setAutoCommit(false);
						System.out.println("어둠속의 괴물을 처치했다");
						debuff = false;
						// 경험치 획득
						int expearn = MobCreate.mo.exp + SelectPlayer.ch.exp;
						if (expearn != 100) {
							x = String.format("update user_ch set c_hp=%d,exp=%d where c_name='%s';", userhpleft,
									expearn, SelectPlayer.ch.name);
							System.out.println(x);
							DatabaseConnect.dbExecuteUpdate(x);

						} else if (expearn == 100 || expearn > 100) {
							playerlevel += 1;
							x1 = String.format("update user_ch set c_hp=%d, exp=%d ,c_level=%d where c_name='%s';",
									userhpleft, expearn, playerlevel, SelectPlayer.ch.name);
							System.out.println(x1);
							userExp = 0;
							DatabaseConnect.dbExecuteUpdate(x1);
						}

						// 모든 쿼리 실행되면 커밋
						DatabaseConnect.con.commit();
					} catch (SQLException e) {
						try {
							DatabaseConnect.con.rollback();
						} catch (SQLException rollbackEx) {
							rollbackEx.printStackTrace();
						}
						e.printStackTrace();
					} finally {
						try {
							DatabaseConnect.con.setAutoCommit(true);
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}

					break loop_x;
				} else if (userhpleft <= 0) {
					System.out.println("당신은 괴물에게 살해당했다");
					dor = false;
					break loop_x;
				}
				break;
			case "2":
				// 방어 처리 방어시 피해 없음
				if (SelectPlayer.ch.job.equals("중보병")) {
					System.out.println("당신은 신속하게 방패를 올렸다");
				} else if (SelectPlayer.ch.job.equals("기사")) {
					System.out.println("당신은 검을 고처쥐어 방어 자세를 취했다");
				} else {
					System.out.println("당신은 품에 있는 단검을 쥐어 방어 자세를 취했다");
				}
				System.out.println("적의 공격 , 당신은 공격을 받아냈다");

				break;
			case "3":
				System.out.println("당신은 필사적으로 도망치려고 한다");
				System.out.println("(주사위 값이 2이하거나 5이상)");
				if (rdi.run() <= 2 || rdi.run() >= 5) {
					if (SelectPlayer.ch.job.equals("중보병")) {
						System.out.println("당신은 분하였지만 살아남고자 한다");

					} else if (SelectPlayer.ch.job.equals("기사")) {
						System.out.println("당신은 자신의 명예가 땅에 떨어진것 같은 수치심을 느낀다");
					}
					System.out.println("당신은 무사히 도망쳤다.");
					System.out.println("공포로 인해 전의를 잃은 당신은 다음 전투에 패널티를 받는다(공격력-20).");

					debuff = true;

				} else {

					dor = false;
					if (dor == false) {
						System.out.println("도망치는데 실패하였다.");
						continue loop_x;
					}
				}
				break loop_x;

			case "4":
				// 현제 스테이터스 보기
				pcs = new PlayCharStat();
				pcs.run();
				break;
			case "5":
				break;
			default:
				break;
			}

		}

	}
}
