package com.rpg.java;

import com.rpg.character.java.SelectPlayer;
import com.rpg.interact.java.RolldiceInteraction;
import com.rpg.monster.java.MobCreate;
import com.rpg.sqldata.java.DatabaseConnect;

public class CompareSpeed {
//	SelectPlayer slp = new SelectPlayer();
//	MobCreate mc = new MobCreate();
	RolldiceInteraction rdi = new RolldiceInteraction();

	public boolean run() {
		int charspeed = SelectPlayer.ch.speed;
		int mobspeed = MobCreate.mo.speed;
		DatabaseConnect.dbInit();
//		String a = String.format("select mo_speed from mob_mo where mo_name ='%s'", mc.name);
		boolean turn = false;

		if (charspeed > mobspeed) {
			System.out.println("당신의 선공");
			turn = true;
		} else if (charspeed < mobspeed) {
			System.out.println("적의 선공");
		} else if (charspeed == mobspeed) {
			System.out.println("주사위를 굴려 3이상일시 선공");
			if (rdi.run() > 3) {
				turn = true;
			}
		}
		return turn;

	}
}
