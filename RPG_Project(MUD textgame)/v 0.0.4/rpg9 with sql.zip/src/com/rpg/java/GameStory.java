package com.rpg.java;

import com.rpg.interact.java.RolldiceInteraction;
import com.rpg.monster.java.MobCreate;
import com.rpg.sqldata.java.DatabaseConnect;

public class GameStory {
	Gamebattle gb;
	MobCreate mc;

	RolldiceInteraction rdi = new RolldiceInteraction();

	public void run() {
		// 스토리 도입
		DatabaseConnect.dbInit();
		System.out.println("어두운 숲속에서 눈을 뜬 당신은 몽롱한 정신으로 기억을 되짚어본다.");
		System.out.println("누워있던 몸을 일으켜 사지가 제대로 움직이는지 확인한다.");
		System.out.println("(주사위를 굴려 1 이상의 수가 나와야한다) ");

		if (rdi.run() >= 1) {
			System.out.println("천천히 몸을 일으킨 당신은 이 숲에 왜 들어오게 되었는지 생각한다.");
			System.out.println("짙은 안개가 깔린 어두운 숲속은 불길한 기운으로 가득 차있다.");
			System.out.println("불쾌한 눅눅함이 당신의 촉감을 자극한다.");
			System.out.println("짐승들의 우는 소리와 나뭇가지의 부스럭거림, 그리고 저 멀리서 들려오는 고통에 찬 낮은 신음소리가 당신의 원초적인 공포를 자극한다.");
			System.out.println("당신은 서둘러 숲을 떠나 마을이 있을만한 방향으로 걷기 시작했다");
//			System.out.println(".");
		}
		loop_b: while (true) {

			System.out.println("(주사위를 굴려 2이하의 수가 나와야한다)");
			if (rdi.run() <= 2) {
				break loop_b;
			} else {
				System.out.println("길을 걸어가는 도중, 살기를 느낀 당신은 서둘러 전투준비를 한다.");
				mc = new MobCreate();
				mc.run("숲");
				gb = new Gamebattle();
				gb.run();
				continue;
			}

		}

		System.out.println("당신은 숲을 벗어나 근방에 있는 마을에 도착하였다");
		System.out.println("하지만 당신은 이내 자신의 눈을 의심한다.");
		System.out.println("그곳은 이미 생기가 사라진지 오래였던것이다.");
		System.out.println("마을 입구에는 알 수 없는 불쾌한 냄새가 났으며");
		System.out.println("망자가 되어버린 주민들에 눈에는 광기만이 있었다");
		System.out.println("망자들 사이에서 당신은 조심히 길을 지나간다.");
		loop_a: while (true) {
			// 아니 왜 잘 돌아가다가 여기서 이상해지는건데?
			// 주사위 5이하였잖아 주사위 5이하였잖아주사위 5이하였잖아주사위 5이하였잖아주사위 5이하였잖아주사위 5이하였잖아주사위 5이하였잖아주사위
			// 5이하였잖아주사위 5이하였잖아주사위 5이하였잖아
			System.out.println("(주사위를 굴려 5이상의 수가 나와야한다)");
			if (rdi.run() >= 5) {
				break loop_a;
			} else {
				System.out.println("길을 걸어가는 도중, 살기를 느낀 당신은 서둘러 전투준비를 한다.");
				mc = new MobCreate();
				mc.run("마을");
				gb = new Gamebattle();
				gb.run();
				continue;
			}

		}

	}
}
