package com.rpg.member.java;

import java.sql.SQLException;
import java.util.Scanner;

import com.rpg.sqldata.java.DatabaseConnect;

public class MemberLogin {
	Scanner sc = new Scanner(System.in);
	static public String userid;
	public boolean ismembertrue = false;

	public boolean run() {
		DatabaseConnect.dbInit();

		System.out.println("id :");
		userid = sc.next();
		System.out.println("pw :");
		int userpw = sc.nextInt();

		String x = String.format("select * from rpg_member where id_member='%s' and pw_member=%d;", userid, userpw);

		try {
			DatabaseConnect.result = DatabaseConnect.st.executeQuery(x);
			while (DatabaseConnect.result.next()) {
				ismembertrue = true;
				System.out.println("로그인 완료!");
			}
			if (!ismembertrue) {
				System.out.println("계정 정보가 다릅니다. 다시 로그인 해주세요");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ismembertrue;

	}
}
