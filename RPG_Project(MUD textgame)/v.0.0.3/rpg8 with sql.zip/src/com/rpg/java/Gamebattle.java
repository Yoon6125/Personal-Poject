package com.rpg.java;

import java.util.Scanner;

import com.rpg.character.java.SelectPlayer;
import com.rpg.interact.java.RolldiceInteraction;
import com.rpg.monster.java.MobCreate;
import com.rpg.sqldata.java.DatabaseConnect;

public class Gamebattle {
	RolldiceInteraction rdi = new RolldiceInteraction();
	MobCreate mc = new MobCreate();
	SelectPlayer spl = new SelectPlayer();
	CompareSpeed cs = new CompareSpeed();
	Scanner sc = new Scanner(System.in);
//	int damCalcuser = (int) (Math.random() * (spl.charAp - mc.moDp)) + 1;
//	int damCalcmob = (int) (Math.random() * (mc.moAp - spl.charDp)) + 1;
	int userhp = spl.charHp;
	int mobhp = mc.moHp;
	int playerlevel = spl.charLevel;

	boolean debuff = false;
	boolean dor = true;

	private int calculateDamage(int attpw, int defpow) {
		return Math.max(1, (int) (Math.random() * (attpw - defpow)) + 1);
	}

	public boolean run() {
		DatabaseConnect.dbInit();
		// 디버프 적용 여부 확인
		int userAttackPower = debuff ? spl.charAp - 20 : spl.charAp;
		int userhpleft = userhp;
		int mobhpleft = mobhp;

//		if (debuff == true) {
//			damCalcuser = damCalcuser - 20;
//		}
		System.out.println(mc.name + "이 나타났다");

		if (cs.run() == false) {
			System.out.println("적의 공격: 당신은 피해를 입었다");
			int damCalcmob = calculateDamage(mc.moAp, spl.charDp);
			userhpleft -= damCalcmob;
		}
		System.out.println("전투 개시");
		loop_x: while (true) {
			System.out.println("1.공격        2.방어       3.도망");
			String choose = sc.nextLine();
			switch (choose) {
			case "1":
				// 공격 처리
				int damCalcuser = calculateDamage(userAttackPower, mc.moDp);
				int damCalcmob = calculateDamage(mc.moAp, spl.charDp);
				System.out.println("당신은 적에게 일격을 날렸다");
				mobhpleft -= damCalcuser;
				// 적 생존시 반격
				if (mobhpleft > 0) {
					System.out.println("적 또한 당신에게 일격을 날렸다");
					userhpleft -= damCalcmob;
					System.out.println("당신은" + damCalcmob + "의 피해를 입었다");
				}
				// 전투 종료
				if (mobhpleft <= 0) {
					System.out.println("어둠속의 괴물을 처치했다");
					dor = false;
					int expearn = mc.moExp + spl.charExp;
					String x = String.format("update user_ch set c_hp=%d,exp=%d where c_name='%s';", userhpleft,
							expearn, spl.charName);
					DatabaseConnect.dbExecuteUpdate(x);

					if (expearn > 100) {
						playerlevel += 1;
						String x1 = String.format("update user_ch set c_hp=%d,exp=%d c_level=%d, where c_name='%s';",
								userhpleft, expearn, playerlevel, spl.charName);
						DatabaseConnect.dbExecuteUpdate(x1);
					}
					break loop_x;
				} else if (userhpleft <= 0) {
					System.out.println("당신은 괴물에게 살해당했다");
					dor = false;
					break loop_x;
				}
				break;
			case "2":
				// 방어 처리 방어시 피해 없음
				if (spl.charJob.equals("중보병")) {
					System.out.println("당신은 신속하게 방패를 올렸다");
				} else if (spl.charJob.equals("기사")) {
					System.out.println("당신은 검을 고처쥐어 방어 자세를 취했다");
				} else {
					System.out.println("당신은 품에 있는 단검을 쥐어 방어 자세를 취했다");
				}
				System.out.println("적의 공격 , 당신은 공격을 받아냈다");

				break;
			case "3":
				System.out.println("당신은 필사적으로 도망치려고 한다");
				System.out.println("(주사위 값이 2이하거나 5이상)");
				if (rdi.run() <= 2 || rdi.run() >= 5) {
					if (spl.charJob.equals("중보병")) {
						System.out.println("당신은 분하였지만 살아남고자 한다");

					} else if (spl.charJob.equals("기사")) {
						System.out.println("당신은 자신의 명예가 땅에 떨어진것 같은 수치심을 느낀다");
					}
					System.out.println("당신은 무사히 도망쳤다.");
					System.out.println("공포로 인해 전의를 잃은 당신은 다음 전투에 패널티를 받는다(공격력-20).");
					dor = false;
					debuff = true;
				} else {
					System.out.println("도망치는데 실패하였다.");
				}
				break loop_x;
			default:
				break;
			}

		}
		return dor;

	}
}
