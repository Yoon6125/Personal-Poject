package com.rpg.member.java;

import java.util.Scanner;

import com.rpg.logo.java.TitleLogo;
import com.rpg.sqldata.java.DatabaseConnect;

public class MemberLoginMain {
	TitleLogo tl = new TitleLogo();
	MemberLogin ml = new MemberLogin();
	MemberRegister mr = new MemberRegister();
	Scanner sc = new Scanner(System.in);

	public boolean run() {
		DatabaseConnect.dbInit();
		boolean isexittrue = false;
		loop_ab: while (true) {
			tl.run();
			System.out.println("[l] 로그인   [r] 회원가입   [x] 종료");
			String loginchoose = sc.nextLine();
			switch (loginchoose) {
			case "l":
				if (ml.run() == true) {
					break loop_ab;
				}
				break;
			case "r":
				mr.run();
				break;
			case "x":
				isexittrue = true;
				break loop_ab;
			default:
				break;

			}
		}
		return isexittrue;

	}
}
