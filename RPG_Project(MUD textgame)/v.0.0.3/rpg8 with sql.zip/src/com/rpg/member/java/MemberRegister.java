package com.rpg.member.java;

import java.util.Scanner;

import com.rpg.sqldata.java.DatabaseConnect;

public class MemberRegister {
	Scanner sc = new Scanner(System.in);

	public void run() {
		DatabaseConnect.dbInit();

		System.out.println("------------------회원가입-------------------");
		System.out.println("id (최대 8자리):");
		String member_id = sc.next();
		System.out.println("pw (최대 8자리):");
		int member_pw = sc.nextInt();

		String s = String.format("insert into rpg_member(id_member, pw_member) values('%s',%d);", member_id, member_pw);
		DatabaseConnect.dbExecuteUpdate(s);

	}
}
