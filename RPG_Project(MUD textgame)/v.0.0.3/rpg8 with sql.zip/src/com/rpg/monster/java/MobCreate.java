package com.rpg.monster.java;

import java.sql.SQLException;
import java.util.ArrayList;

import com.rpg.sqldata.java.DatabaseConnect;

public class MobCreate {
	static public String name = "";
	static public int moAp = 0;
	static public int moDp = 0;
	static public int moHp = 0;
	static public int moExp = 0;

	public void run(String a) {
		DatabaseConnect.dbInit();
		ArrayList<String> a1 = new ArrayList<>();
		int mobnum = (int) (Math.random() * 2 + 1);
		int idtt = 0;

//		int idtt2 = 0;
		String b = String.format("select * from mob_mo where region='%s'", a);
		try {
			DatabaseConnect.result = DatabaseConnect.st.executeQuery(b);
			while (DatabaseConnect.result.next()) {
				moAp = DatabaseConnect.result.getInt("mo_attackpoint");
				moDp = DatabaseConnect.result.getInt("mo_defencepoint");
				moHp = DatabaseConnect.result.getInt("mo_hp");
				moExp = DatabaseConnect.result.getInt("exp");
				a1.add(DatabaseConnect.result.getString("mo_name"));

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int mobIndex = (int) (Math.random() * a1.size());
		name = a1.get(mobIndex);

	}
}
