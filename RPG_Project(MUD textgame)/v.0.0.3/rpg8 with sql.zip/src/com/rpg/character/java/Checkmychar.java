package com.rpg.character.java;

import java.sql.SQLException;
import java.util.ArrayList;

import com.rpg.member.java.MemberLogin;
import com.rpg.sqldata.java.DatabaseConnect;

public class Checkmychar {
	MemberLogin ml = new MemberLogin();
	String a = "";
	ArrayList<String> d = new ArrayList<String>();

	public void run() {
		DatabaseConnect.dbInit();

//		boolean hasCharacter = false;
		String sql = String.format("select * from rpg_memberanduser where id_member ='%s';", ml.userid);
		try {
			DatabaseConnect.result = DatabaseConnect.st.executeQuery(sql);
			d.clear();
			while (DatabaseConnect.result.next()) {
				d.add(DatabaseConnect.result.getString("c_name"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("********캐릭터 목록***********");
		for (int i = 0; i < d.size(); i++) {
			DatabaseConnect.dbInit();
			a = String.format("select * from user_ch where c_name='%s';", d.get(i));
			DatabaseConnect.dbExecuteQuery(a);
		}
	}
}
