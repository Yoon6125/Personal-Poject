package com.rpg.character.java;

import java.util.Scanner;

import com.rpg.sqldata.java.DatabaseConnect;

public class DeleteCharacter {
	Scanner sc = new Scanner(System.in);

	public void run() {
		DatabaseConnect.dbInit();
		System.out.println("삭제할 캐릭터 명을 입력해주세요:");
		String choosedel = sc.nextLine();
		String x = String.format("delete from user_ch where c_name='%s';", choosedel);
		boolean token = false;

		if (!choosedel.equals(null)) {
			loop_xy: while (true) {
				System.out.println("정말로 삭제하시겠습니까? 한번 삭제한 캐릭터는 복구할수  없습니다.");
				System.out.println("1.yes        2.no");
				String lastchance = sc.nextLine();
				switch (lastchance) {
				case "1":
					token = true;
					DatabaseConnect.dbExecuteUpdate(x);
					System.out.println("성공적으로 삭제되었습니다.");
					break loop_xy;
				case "2":
					System.out.println("메뉴로 돌아갑니다");
					break loop_xy;
				default:
					continue;
				}

			}
		}
	}
}
