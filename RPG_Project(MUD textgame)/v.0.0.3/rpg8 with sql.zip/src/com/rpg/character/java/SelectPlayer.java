package com.rpg.character.java;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.rpg.member.java.MemberLogin;
import com.rpg.sqldata.java.DatabaseConnect;

public class SelectPlayer {
	Scanner sc = new Scanner(System.in);
	MemberLogin ml = new MemberLogin();
	String a = "";
	static public String charName = "";
	static public String charJob = "";
	static public int charLevel = 0;
	static public int charAp = 0;
	static public int charDp = 0;
	static public int charHp = 0;
	static public int charSpeed = 0;
	static public int charExp = 0;

	public boolean run() {
		System.out.println("********캐릭터 목록***********");
		for (int i = 0; i < CharacterExist.cha_data.size(); i++) {
			DatabaseConnect.dbInit();
			a = String.format("select * from user_ch where c_name='%s';", CharacterExist.cha_data.get(i));
			DatabaseConnect.dbExecuteQuery(a);
		}

		boolean chooseCharacter = false;

		System.out.println("플레이할 캐릭터 이름을 타이핑 하세요 :");
		String choosechar = sc.nextLine();
		if (choosechar != null && !choosechar.isEmpty()) {
			String b = String.format("select * from user_ch where c_name ='%s';", choosechar);

			try {
				ResultSet result = DatabaseConnect.st.executeQuery(b);
				if (result.next()) {
					// 캐릭터가 존재하면 선택 완료
					charName = result.getString("c_name");
					charJob = result.getString("c_job");
					charLevel = result.getInt("c_level");
					charSpeed = result.getInt("c_speed");
					charAp = result.getInt("c_attackpoint");
					charDp = result.getInt("c_defencepoint");
					charHp = result.getInt("c_hp");
					charExp = result.getInt("exp");
					System.out.println("캐릭터 선택 완료: " + charName + " (직업: " + charJob + ", 레벨: " + charLevel + ")");
					chooseCharacter = true; // 캐릭터 선택 성공
				} else {
					System.out.println("선택한 캐릭터가 존재하지 않습니다.");
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {
			System.out.println("올바른 캐릭터명을 입력하세요");
		}

		return chooseCharacter;
	}
}
